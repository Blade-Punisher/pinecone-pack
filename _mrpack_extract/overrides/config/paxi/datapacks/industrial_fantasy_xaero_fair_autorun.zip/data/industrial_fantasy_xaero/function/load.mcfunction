scoreboard objectives add if_xaero_fair dummy
