execute as @a unless score @s if_xaero_fair matches 1 run function xaero:silent/fairxaero
execute as @a unless score @s if_xaero_fair matches 1 run scoreboard players set @s if_xaero_fair 1
