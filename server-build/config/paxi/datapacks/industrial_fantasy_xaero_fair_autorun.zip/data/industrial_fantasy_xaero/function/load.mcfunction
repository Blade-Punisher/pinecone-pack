# Apply Xaero fair map rules once when the world/datapack loads
execute as @a at @s run function xaero:silent/fairxaero
# One delayed check after startup, then stop
schedule function industrial_fantasy_xaero:check 10s replace
