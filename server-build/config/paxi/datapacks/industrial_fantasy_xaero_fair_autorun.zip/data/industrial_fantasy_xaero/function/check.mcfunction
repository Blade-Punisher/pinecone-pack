# One delayed re-apply after startup. This function does not reschedule itself.
execute as @a at @s run function xaero:silent/fairxaero
