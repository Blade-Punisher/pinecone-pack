function xaero:silent/fairxaero
schedule function industrial_fantasy_xaero:apply 10s replace
