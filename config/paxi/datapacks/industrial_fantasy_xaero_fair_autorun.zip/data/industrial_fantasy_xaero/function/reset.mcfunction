# Full reset for testing.
scoreboard players reset @a if_xaero_last_leave
scoreboard players set @a if_xaero_applied 0
function industrial_fantasy_xaero:apply
