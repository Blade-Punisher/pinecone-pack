# Manual test helper: /function industrial_fantasy_xaero:reset
tag @a remove industrial_fantasy_xaero_fair_applied
function industrial_fantasy_xaero:apply
