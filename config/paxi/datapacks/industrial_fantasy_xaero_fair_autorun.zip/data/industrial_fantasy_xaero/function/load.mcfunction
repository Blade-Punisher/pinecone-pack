# Industrial Fantasy Xaero Fair Autorun
scoreboard objectives add if_xaero_timer dummy
scoreboard players set #timer if_xaero_timer 100
function industrial_fantasy_xaero:apply
