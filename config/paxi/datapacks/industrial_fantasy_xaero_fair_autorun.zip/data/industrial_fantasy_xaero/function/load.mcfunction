# Starts delayed fair-map check loop after world/server load
schedule function industrial_fantasy_xaero:apply 1s replace
