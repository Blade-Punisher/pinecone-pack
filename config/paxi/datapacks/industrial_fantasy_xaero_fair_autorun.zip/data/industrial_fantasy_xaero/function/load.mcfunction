# Xaero fair map autorun for every player login session.
# Existing-objective errors after /reload are harmless.
scoreboard objectives add if_xaero_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add if_xaero_last_leave dummy
scoreboard objectives add if_xaero_applied dummy

# Start a lightweight check loop.
schedule function industrial_fantasy_xaero:apply 1s replace
