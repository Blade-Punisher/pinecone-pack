# Applies Xaero fair mode only to players who have not been processed yet
execute as @a[tag=!industrial_fantasy_xaero_fair_applied] at @s run function xaero:silent/fairxaero
tag @a[tag=!industrial_fantasy_xaero_fair_applied] add industrial_fantasy_xaero_fair_applied

# Keeps a light check running for players who join later; already processed players are skipped
schedule function industrial_fantasy_xaero:apply 10s replace
