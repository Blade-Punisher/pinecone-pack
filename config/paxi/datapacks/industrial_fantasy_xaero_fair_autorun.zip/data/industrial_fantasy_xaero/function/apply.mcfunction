# Initialize writable helper scores for online players.
scoreboard players add @a if_xaero_last_leave 0
scoreboard players add @a if_xaero_applied 0

# When a player has left since the last successful apply, treat the current login as a new session.
execute as @a if score @s if_xaero_leave > @s if_xaero_last_leave run scoreboard players set @s if_xaero_applied 0

# Apply Xaero fair mode once for this login session.
execute as @a[scores={if_xaero_applied=0}] at @s run function xaero:silent/fairxaero

# Mark players as processed for the current login session.
scoreboard players set @a[scores={if_xaero_applied=0}] if_xaero_applied 1

# Remember the current leave counter so the next reconnect triggers a fresh apply.
execute as @a if score @s if_xaero_leave matches 0.. run scoreboard players operation @s if_xaero_last_leave = @s if_xaero_leave

# Keep checking for later joins. The heavy Xaero function runs only once per login session.
schedule function industrial_fantasy_xaero:apply 3s replace
