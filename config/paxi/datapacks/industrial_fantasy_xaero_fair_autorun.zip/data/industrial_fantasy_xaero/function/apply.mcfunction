# Applies Xaero fair rules to every online player
execute as @a at @s run function xaero:silent/fairxaero
