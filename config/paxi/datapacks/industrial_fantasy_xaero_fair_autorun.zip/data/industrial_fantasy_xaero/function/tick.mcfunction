# Runs every tick, applies fairxaero every 5 seconds
scoreboard objectives add if_xaero_timer dummy
scoreboard players add #timer if_xaero_timer 1
execute if score #timer if_xaero_timer matches 100.. run function industrial_fantasy_xaero:apply
execute if score #timer if_xaero_timer matches 100.. run scoreboard players set #timer if_xaero_timer 0
