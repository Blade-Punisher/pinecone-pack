# Force apply to all currently online players once.
scoreboard players set @a if_xaero_applied 0
function industrial_fantasy_xaero:apply
